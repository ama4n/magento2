<?php

namespace Plugin\Test\Model\Rewrite\Catalog;
class Product extends \Magento\Catalog\Model\Product
{
// public function __construct()
// {
//  echo "Overrding/ Rewrite Working";
//    die();
// }
}