<?php

namespace Plugin\Test\Model;

interface PageInterface{
	
	public function setName($name);
	public function getName();
	
}