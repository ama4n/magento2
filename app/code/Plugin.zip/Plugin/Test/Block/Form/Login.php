<?php
namespace Plugin\Test\Block\Form;
class Login extends  \Magento\Customer\Block\Form\Login
{
    
   
    
    public function getForgotPasswordUrl()
    {
        return "https://webkul.com/blog/overriding-rewriting-classes-magento2/";
    }

}