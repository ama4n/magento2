<?php
namespace Plugin\Test\Block;
class Index extends \Magento\Framework\View\Element\Template
{
     protected $_pageFactory;
     protected $_postLoader;
     protected $PageName;
     public function __construct(
          \Magento\Framework\View\Element\Template\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Plugin\Test\Model\Page\PageName $PageName
     ){
          $this->_pageFactory = $pageFactory;
          $this->PageName = $PageName;
          return parent::__construct($context);
     }
     public function execute()
     {
          return $this->_pageFactory->create();
     }
     public function pagetitleobj(){
        return $this->PageName;
    }
}