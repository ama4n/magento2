<?php
    namespace Plugin\Test\Controller\Index;
    // use Magento\Catalog\Api\ProductRepositoryInterface;
    // use Magento\Catalog\Model\Design;
    // use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
    // use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
    // use Magento\Framework\App\Action\Context;
    // use Magento\Framework\App\ObjectManager;
    // use Magento\Framework\Controller\Result\Forward;
    // use Magento\Framework\Controller\Result\ForwardFactory;
    // use Magento\Framework\Controller\Result\Redirect;
    // use Magento\Framework\DataObject;
    // use Magento\Framework\Exception\NoSuchEntityException;
    // use Magento\Framework\Json\Helper\Data;
    // use Magento\Framework\View\Result\PageFactory;
    // use Magento\Catalog\Controller\Product as ProductAction;
    // use Magento\Store\Model\StoreManagerInterface;
    // use Psr\Log\LoggerInterface;
   
    class View extends  \Magento\Catalog\Controller\Product\View 
     {
    //     protected $orderRepository;

    //     public function __construct(
          
    //         Context $context,
    //         \Magento\Catalog\Helper\Product\View $viewHelper,
    //         \Magento\Sales\Model\OrderFactory $orderFactory,
    //         \Magento\Payment\Model\Config\Source\Allmethods $allPaymentMethod,
    //         \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
    //         \Magento\Sales\Model\Order\ItemFactory $itemFactory,
           
    //         ForwardFactory $resultForwardFactory,
    //         PageFactory $resultPageFactory,
    //         ?LoggerInterface $logger = null,
    //         ?Data $jsonHelper = null,
    //         ?Design $catalogDesign = null,
    //         ?ProductRepositoryInterface $productRepository = null,
    //         ?StoreManagerInterface $storeManager = null
          
            
    //     )
    //     {        $this->itemFactory = $itemFactory;
    //             $this->orderRepository = $orderRepository;
    //             $this->allPaymentMethod = $allPaymentMethod;
    //             $this->orderFactory = $orderFactory;
    //             $this->viewHelper = $viewHelper;
    //             $this->resultForwardFactory = $resultForwardFactory;
    //             $this->resultPageFactory = $resultPageFactory;
    //             $this->logger = $logger ?: ObjectManager::getInstance()
    //                 ->get(LoggerInterface::class);
    //             $this->jsonHelper = $jsonHelper ?: ObjectManager::getInstance()
    //                 ->get(Data::class);
    //             $this->catalogDesign = $catalogDesign ?: ObjectManager::getInstance()
    //                 ->get(Design::class);
    //             $this->productRepository = $productRepository ?: ObjectManager::getInstance()
    //                 ->get(ProductRepositoryInterface::class);
    //             $this->storeManager = $storeManager ?: ObjectManager::getInstance()
    //                 ->get(StoreManagerInterface::class);
    //                 parent::__construct($context,$viewHelper, $resultForwardFactory,$resultPageFactory,$logger,$jsonHelper, $catalogDesign,$productRepository,$storeManager);   
    //     }      
        // public function execute()
        // {
            // die("hhhh");
            // echo "hhhhhh";


            



            // $orderIncrementId = 2;
            // $order = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);
            //  $p= $order->getPayment();
            // //  print_r($p);

            // echo "<pre>";
            // print_r(get_class_methods($order));
           
            // $orderId = $order->getIncrementId();
            //  echo $orderId;

                           
         


            //  
        //    $method = $this->allPaymentMethod->toOptionArray();
        //     $p=$method['braintree_group'];
          
        // //    foreach($method as $paymentCode => $payment) {
        // //     echo "<pre>";print_r($method);
        // // }
                     
        //    echo "<pre>";
        //    print_r($p);
// ===================================================================================
//         $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

//         $scope = $objectManager->create('\Magento\Framework\App\Config\ScopeConfigInterface');
//         $methodList = $scope->getValue('payment');
      
//    foreach( $methodList as $code => $_method )
//   {

//       echo "<br>";
//         echo $code;
//         echo "<br>";
   

// }
// ========================================================================================================

// $orders = Mage::getResourceModel('sales/order_collection');
// foreach($orders as $order){
//     $items = $order->getAllVisibleItems();
//     foreach($items as $item){
//         $sku = $item->getSku();
//     }
// }

//    $order = $this->itemFactory->create();
//    echo "<pre>";
//    print_r(get_class_methods($order));

        // }
    }