<?php
namespace  Plugin\Test\Controller\Index;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Input\InputOption;
use Magento\Framework\File\Csv;
use Magento\Framework\App\Area;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Sales\Model\OrderFactory ;
use Magento\Sales\Model\Order\ItemFactory ;


class Console extends Command
{
   
    protected $orderFactory;
    protected $itemFactory;
    public function __construct(
        ItemFactory $itemFactory,
       
        OrderFactory $orderFactory,
        Csv $csv,
        DirectoryList $directoryList,
        ResourceConnection $resource,
        string $name = null
    ) {
        parent::__construct($name);
        $this->itemFactory = $itemFactory;
       
        $this->orderFactory = $orderFactory;
        $this->csv = $csv;
        $this->directoryList = $directoryList;
    }
   protected function configure()
   {
       $this->setName('example:sayhello');
       $this->setDescription('Demo command line');
       $this->setDefinition([
        new InputOption('importData',null, InputOption::VALUE_OPTIONAL, 'import the csv file'),
    
        ]);
    
       parent::configure();
   }
   protected function execute(InputInterface $input, OutputInterface $output)
   {
       $output->writeln("Hello World");
   
       $input->getOption('importData');
        $this->importCsvFile();
    
    
     
   }
  
   private function importCsvFile() 
   {
      $filename = 'myimportcsvfile.csv';
      $file = $this->directoryList->getPath('var') . DIRECTORY_SEPARATOR . $filename ;
      $csvData = fopen($file, 'w');
      $data = [];
      $exportData = [];
      $exportData[] = $this->getHeaders();
      $arr=[];
      $orderIncrementId = 3;
      $order = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);
   
        $exportData[] =[
         $order->getIncrementId(),
         $order->getQuoteId(),
         $order->getPayment()->getMethod(),
         $this->getSku()
     
        ];

    $this->csv->saveData($file,$exportData);
      
   }
   private function getHeaders()
   {
       $data = [
           'Order_Id',
           'QuteId', 
           'PaymentMethod',
           'Item'
       ];
       return $data;
   }
 

   public function getAllPaymentMethods()
   {
    $orderIncrementId=0000003;
    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $order = $objectManager->create('Magento\Sales\Model\Order')->loadByIncrementId($orderIncrementId);
    $payment = $order->getPayment();
    $method = $payment->getMethodInstance();
    $methodTitle = $method->getTitle();
    return $methodTitle;
 }
 public function getSku()
 {
    $order = $this->itemFactory->create()->getCollection();
    $sku=[];
   foreach ($order as $items)
  {
       $sku[]= $items->getSku(); 
    }
    $allSku= implode(",", $sku);
    return $allSku;
 }

}